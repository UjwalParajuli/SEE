<?php

// Start the session
session_start();


if(isset($_GET['delete'])){
	$id = $_GET['delete'];

	include 'db.php';
	$sql = "select image from user where id = $id ";
	$result2 = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result2);
    $imagepath = $row['image'];
    $imagepath2 = 'https://ujwalparajuli.000webhostapp.com/android/uploads/user/dummy_user.jpg';
    if($imagepath != $imagepath2){
        $name = basename($imagepath);
        $path = "../android/uploads/user/$name";
        unlink($path);
    }
	
	$query = "delete from user where id = $id ";
	$result = mysqli_query($conn, $query);
	if($result){
	    $_SESSION['res_type'] = "danger";
	    $_SESSION['response'] = "Successfully Deleted";
		header('location:viewCustomers.php');
		
		//echo "<META http-equiv='refresh' content='0 ;URL=viewCustomers.php'>";
		
	}
}

if (isset($_GET['update'])) {
	$id = $_GET['update'];
	include 'db.php';
	$sql = "update user set user_type_id = 2 where id = $id ";
	$result = mysqli_query($conn, $sql);
	if($result){
		$_SESSION['response'] = "Successfully Changed";
		$_SESSION['res_type'] = "success";
		header('location:viewCustomers.php');
	}
}

if (isset($_GET['update2'])) {
	$id = $_GET['update2'];
	include 'db.php';
	$qry = "select email from user where id = $id ";
	$_result = mysqli_query($conn, $qry);
	$row = mysqli_fetch_array($_result);
	$email = $row['email'];
	
	$sql = "update user set user_type_id = 3 where id = $id ";
	$result = mysqli_query($conn, $sql);
	if($result){
	    	$to = $email; // Add your email address inbetween the '' replacing yourname@yourdomain.com - This is where the form will send a message to.
		$email_subject = "Search Event Everywhere | User Type Change Request";
		$email_body = "Your request to change your account type to Event Organizer has been approved."."\n\n"."Now you can add your event in the application". "\n\n" . "Thank you for choosing us.";
		$headers = "From: info@ujwalparajuli.com.np\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
		$headers .= "Reply-To: uzwalparajuli07@gmail.com";   
		mail($to,$email_subject,$email_body,$headers);
		$_SESSION['response'] = "Successfully Changed";
		$_SESSION['res_type'] = "success";
		header('location:viewOrganizers.php');
	}
}

if (isset($_GET['details'])) {
	$id = $_GET['details'];

	include 'db.php';
	$qry = "select * from user where id = $id ";
	$result = mysqli_query($conn, $qry);
	$row = mysqli_fetch_array($result);

	$u_id = $row['id'];
	$u_name = $row['full_name'];
	$u_email = $row['email'];
	$u_phone = $row['phone'];
	$u_address = $row['address'];
	$u_image = $row['image'];
}

if (isset($_POST['btnChange'])) {
	$id = $_SESSION['id'];
	$old_password = $_SESSION['password'];
	

	

	if ($_POST['current'] != $old_password) {
		$_SESSION['response'] = "Current Password Doesn't Matched";
		$_SESSION['res_type'] = "danger";
		header('location:changePassword.php');
	}
	elseif (strlen($_POST['new']) < 6) {
		$_SESSION['response'] = "Password must be 6 or more character long";
		$_SESSION['res_type'] = "danger";
		header('location:changePassword.php');
	}
	elseif ($_POST['new'] != $_POST['confirm']) {
		$_SESSION['response'] = "Password Doesn't Matched";
		$_SESSION['res_type'] = "danger";
		header('location:changePassword.php');
	}
	else{
	    $password = $_POST['confirm'];
		$hashed_password = password_hash($password, PASSWORD_DEFAULT);
		include 'db.php';
		$qry = "update user set password = '$hashed_password' where id = $id ";
		$result = mysqli_query($conn, $qry);
		if($result){
			$_SESSION['response'] = "Successfully Changed";
			$_SESSION['res_type'] = "success";
			$_SESSION['password'] = $_POST['confirm'];
			header('location:changePassword.php');
		}
	
	}
		
	}





?>