<script>
    $(function(){
    $('a#logout').click(function(){
        if(confirm('Are you sure want to logout?')) {
            return true;
        }

        return false;
    });
});
</script>
<style>
	.header {
  overflow: hidden;
  background-color: white;
  padding: 20px 10px;
}

/* Style the header links */
.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  line-height: 25px;
  border-radius: 4px;
}

/* Style the logo link (notice that we set the same value of line-height and font-size to prevent the header to increase when the font gets bigger */
.header img{
    float: left;
    width: 50px;
    height: 50px;
}
.header a.logo {
    font-size: 25px;
  font-weight: bold;
  
}

/* Change the background color on mouse-over */
.header a:hover {
  
  color: #B37358;
}

/* Style the active/current link*/
.header a.active {
  
  color: #B37358;
}

/* Float the link section to the right */
.header-right {
  float: right;
}

/* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */
@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  .header-right {
    float: none;
  }
}
</style>

	<div class="header">
	    <img src="images/logo.svg" alt="App Logo">
	  <a href="home.php" class="logo">Search Event Everywhere</a>
	  <div class="header-right">
	    <a href="home.php">Home</a>
	    <a href="viewCustomers.php">View Customers</a>
	    <a href="viewOrganizers.php">View Event Organizers</a>
	    <a href="changePassword.php">Change Password</a>
        <a href="logout.php" id="logout">Log Out</a>
	  </div>
</div>





