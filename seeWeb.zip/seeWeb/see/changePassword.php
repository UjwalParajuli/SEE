<?php  
  
// Starting the session, necessary 
// for using session variables
session_set_cookie_params(0);
session_start(); 
if(!$_SESSION["logged_in"]){
    header('location:adminLogin.php');
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Change Password</title>
	 <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="images/site.webmanifest">
	
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	<style>
	body{
				background-color: #F2F2F2;
				font-family: Arial, Helvetica, sans-serif;
			}
			.btn:hover{
			    background-color: #8D5B45;
			    
			}
			.btn{
			    width: 100%;
			    background-color: #B37358;
			    color: white;
			}
		
		.pass_show{position: relative} 

	.pass_show .ptxt { 

	position: absolute; 

	top: 50%; 

	right: 10px; 

	z-index: 1; 

	color: #333333; 

	margin-top: -10px; 

	cursor: pointer; 

	transition: .3s ease all; 

	} 

	.pass_show .ptxt:hover{color: #B37358 ;} 
	</style>
	<script>
	      
    $(document).ready(function(){
    $('.pass_show').append('<span class="ptxt">Show</span>');  
    });
      
    
    $(document).on('click','.pass_show .ptxt', function(){ 
    
    $(this).text($(this).text() == "Show" ? "Hide" : "Show"); 
    
    $(this).prev().attr('type', function(index, attr){return attr == 'password' ? 'text' : 'password'; }); 
    
    });  
	</script>
</head>
<body>
    <?php include 'header.php';?>
	<div class="container-fluid">
	    <br>
	     <?php if(isset($_SESSION['response'])){ ?>
		<div class="alert alert-<?= $_SESSION['res_type']; ?> alert-dismissible text-center">
		  <button type="button" class="close" data-dismiss="alert">&times;</button>
		  <b><?= $_SESSION['response']; ?></b>
		</div>
		<?php } unset($_SESSION['response']); ?>
		<br>
	<div class="row justify-content-center">
		<div class="col-sm-4">
		    <form action="delete.php" method="post">
		       
		    
		    <label>Current Password</label>
		    <div class="form-group pass_show"> 
                <input type="password" class="form-control" name="current" placeholder="Current Password" required> 
            </div> 
		       <label>New Password</label>
            <div class="form-group pass_show"> 
                <input type="password" class="form-control" name="new" placeholder="New Password" required> 
            </div> 
		       <label>Confirm Password</label>
            <div class="form-group pass_show"> 
                <input type="password" class="form-control" name="confirm" placeholder="Confirm Password" required> 
            </div>
             <div class="form-group">
                      
                         <input type="submit" class="btn" name="btnChange" value="Change" onclick="return confirm('Are you sure you want to change your password?');"/>
                      </div>
                      </form>
            
		</div>  
	</div>
</div>
<?php include 'footer.php';?>

</body>
</html>