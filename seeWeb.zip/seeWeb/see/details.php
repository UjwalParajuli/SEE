<?php
	include 'delete.php';
	session_set_cookie_params(0);
	session_start();
	if(!$_SESSION["logged_in"]){
    header('location:adminLogin.php');
}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, intital-scale=1, shrink-to-fit=no">
	 <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="images/site.webmanifest">
	
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	<style>
		body{
			background-color: #F2F2F2;
			font-family: Arial, Helvetica, sans-serif;
		}
		.bg-info {
    		background-color: #B37358!important;
    	}
	</style>
</head>
<body>
	<?php include 'header.php';?>

	<div class="container">
		<div class="row justify-content-center" style="margin-bottom: 50px;">
			<div class="col-md-6 mt-3 bg-info p-4 rounded">
				<h2 class="bg-light p-2 rounded text-center text-dark">ID : <?= $u_id; ?> </h2>
				<div class="text-center">
					<img src="<?= $u_image; ?>" width="300" class="img-thumbnail">
				</div>
				<br>
				<h4 class="text-light">Name : <?= $u_name; ?></h4>
				<h4 class="text-light">Email : <?= $u_email; ?></h4>
				<h4 class="text-light">Phone : <?= $u_phone; ?></h4>
				<h4 class="text-light">Address : <?= $u_address; ?></h4>
			</div>
			
		</div>
	</div>

	<?php include 'footer.php';?>
</body>
</html>