<?php
// Start the session
session_set_cookie_params(0);
session_start();
if(!$_SESSION["logged_in"]){
    header('location:adminLogin.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Manage Customers</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, intital-scale=1">
		 <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="images/site.webmanifest">
	
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	
	<style>
		body{
				background-color: #F2F2F2;
				font-family: Arial, Helvetica, sans-serif;
			}
	    table{
	        background-color: white;
	         margin: auto;
             width: 100% !important;
	    }
	    h3{
	    	text-align: center;
	    }
	</style>
</head>
<body>
	<?php include 'header.php';?>

	<div class="container-fluid">
		<div class="col-md-12">
		    <br/><br/>
		<h3>Customers</h3><hr>
		<?php if(isset($_SESSION['response'])){ ?>
		<div class="alert alert-<?= $_SESSION['res_type']; ?> alert-dismissible text-center">
		  <button type="button" class="close" data-dismiss="alert">&times;</button>
		  <b><?= $_SESSION['response']; ?></b>
		</div>
		<?php } unset($_SESSION['response']); ?>
	

		<?php
			include 'db.php'; 
			$query = "select * from user where user_type_id = 3";
			$result = mysqli_query($conn, $query);
		?>
		<div class="table-responsive">
		<table class="table table-hover">
		    <thead>
		      <tr>
		      	<th>#</th>
		      	<th>Image</th>
		        <th>Full Name</th>
		        <th>Email</th>
		        <th>Phone</th>
		        <th>Address</th>
		        <th>Action</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php while ($row = mysqli_fetch_array($result)) { ?>
		      <tr>
		        <td><?= $row['id']; ?></td>
		        <td><img src="<?= $row['image']; ?>" width="25"></td>
		        <td><?= $row['full_name']; ?></td>
		        <td><?= $row['email']; ?></td>
		        <td><?= $row['phone']; ?></td>
		        <td><?= $row['address']; ?></td>
		        <td>
		        	<a href="details.php?details=<?= $row['id']; ?>" class="badge badge-primary p-2">Details</a>
		        	<a href="delete.php?update=<?= $row['id']; ?>" class="badge badge-success p-2" onclick="return confirm('Are you sure you want to change to Event Organizer?');">Change to Event Organizer</a>
		        	<a href="delete.php?delete=<?= $row['id']; ?>" class="badge badge-danger p-2" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
		        </td>
		      </tr>
		  <?php } ?>
		    </tbody>
		  </table>
		  </div>
	</div>
		
	</div>

    
	
	

	<?php include 'footer.php';?>

</body>
</html>