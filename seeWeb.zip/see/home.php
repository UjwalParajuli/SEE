<?php  
  
// Starting the session, necessary 
// for using session variables 
session_set_cookie_params(0);
session_start();
if(!$_SESSION["logged_in"]){
    header('location:adminLogin.php');
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, intital-scale=1">
	 <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="images/site.webmanifest">
	
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<!------ Include the above in your HEAD tag ---------->

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">
	<style>
		body{
			background-color: #F2F2F2;
			font-family: Arial, Helvetica, sans-serif;
		}
		* {
  box-sizing: border-box;
}
h3{
    color: #B37358;
}
h4{
	text-align: center;
}
/* Float four columns side by side */
.column {
  float: left;
  width: 33%;
  padding: 100px 90px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #ffffff;
}
	</style>
</head>
<body>
	<?php include 'header.php';?>

	<?php
		include 'db.php';
		$qry = "select * from user where user_type_id= 2 ";
		$result = mysqli_query($conn, $qry);
		$total = mysqli_num_rows($result);
		$qry2 = "select * from user where user_type_id= 3 ";
		$result2 = mysqli_query($conn, $qry2);
		$total2 = mysqli_num_rows($result2);
		$qry3 = "select * from event_details";
		$result3 = mysqli_query($conn, $qry3);
		$total3 = mysqli_num_rows($result3);
	?>
	<br>
    <h4>Welcome, <?= $_SESSION['name']; ?></h4>
    <br>
	<div class="row">
	    
	  <div class="column">
	    <div class="card">
	      <h3>Total Events Created</h3>
	      <p><?php echo "$total3";?></p>
	    </div>
	  </div>

	  <div class="column">
	    <div class="card">
	      <h3>Total Customers</h3>
	      <p><?php echo "$total2";?></p>
	    </div>
	  </div>
	  
	  <div class="column">
	    <div class="card">
	      <h3>Total Event Organizers</h3>
	      <p><?php echo "$total";?></p>
	    </div>
	  </div>
	</div>



	<?php include 'footer.php';?>
	

</body>
</html>