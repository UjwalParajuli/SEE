<style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: white;
  color: black;
  text-align: center;
}
</style>

<div class="footer">
  <p>&copy; Search Event Everywhere | 2020</p>
</div>