<?php 
	include 'db.php';
	$qry = "select * from user where id = 2 ";
	$result = mysqli_query($conn, $qry);
	$row = mysqli_fetch_array($result);

	$u_id = $row['id'];
	$u_name = $row['full_name'];
	$u_email = $row['email'];
	$u_phone = $row['phone'];
	$u_address = $row['address'];
	$u_image = $row['image'];
	
	echo $u_name;
	
	
	?>