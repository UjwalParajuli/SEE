<?php  
  
// Starting the session, necessary 
// for using session variables 
session_set_cookie_params(0);
session_start(); 

?>
<!DOCTYPE html>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, intital-scale=1">
    <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
    <link rel="manifest" href="images/site.webmanifest">
	
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">

	<title>Login</title>
	<style>
	body {font-family: Arial, Helvetica, sans-serif; background-color: #F2F2F2;}
form {border: 3px solid #f1f1f1;}
h1{
    margin-top:5px;
    text-align:center;
}
h2{
    text-align:center;
}

input[type=email], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #B37358;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}


.imgcontainer {
	height: auto;
	width:auto;
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
	height: auto;
  width: auto;
  border-radius: 50%;
}

.container{
    width:auto;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}


</style>
</head>
<body>
	<?php
	   
     	$emailErr = $passErr = "";
		$alert = "";
		if (isset($_POST['submit'])) {
			$servername = "localhost";
			$dbname = "id5461621_see";
			$uname = "id5461621_event";
			$pass = "12345";
			$conn = mysqli_connect($servername, $uname, $pass, $dbname);
			if (!$conn) {
				die("Connection failed!");
			}
			$err = false;
			if (empty($_POST['email'])){
				$emailErr = "Email is Required";
				$err = true;
			}
			if(empty($_POST['password'])){
				$passErr = "Password is Required";
				$err = true;		
			}
			if($err == false){
				$email = $_POST['email'];
				$password = $_POST['password'];
				$sql = "select * from user where email = '$email' and user_type_id = 1";
				$result = mysqli_query($conn, $sql);

				if ($row = mysqli_fetch_array($result)) {
					if (!password_verify($password, $row['password'])) {
						$alert = "Invalid username/password.";
					} else {
					    $_SESSION['logged_in'] = true;
					        $_SESSION['id'] = $row['id'];
					        $_SESSION['name'] = $row['full_name'];
					       $_SESSION['password'] = $password;
					       //header('location:home.php');
						   echo "<META http-equiv='refresh' content='0 ;URL=home.php'>";
					}
				} else {
					$alert = "Invalid username/password.";
				}


				// while ($row = mysqli_fetch_array($result))
				// {
				// 	if ($email == $row[2] && password_verify("$password", $row[3])) {
				// 		echo "Matched";
				// 	}
				// 	elseif($email != $row[2] && password_verify("$password", $row[3])){
				// 		$emailErr = "Email Not Found";
				// 	}
				// 	elseif($email == $row[2] && (!password_verify("$password", $row[3]))){
				// 		$passErr = "Invalid Password";
				// 		$emailErr = "Invalid Email";
				// 	}
				// 	elseif($email != $row[2] && (!password_verify("$password", $row[3]))){
				// 		$passErr = "Invalid Password";
				// 		$emailErr = "Invalid Email";
				// 	}
				// }
			}
	
	    }
	
?>
<h1>Search Event Everywhere</h1><br>
<h2>Admin Login</h2>
	<div class="container">
<div class="row justify-content-center">
	<div class="col-sm-4">
	<form action="adminLogin.php" method="post">
  <div class="imgcontainer">
    <img src="images/user.png" alt="Avatar" class="avatar">
  </div>

  	<?php echo $alert; ?>
  	<br>
    <label for="uname"><b>Email</b></label>
    <input type="email" placeholder="Your Email Address" name="email" required>
     <span class="error"> <?php echo "$emailErr";?></span>
	    <br><br>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
      <span class="error"> <?php echo "$passErr";?></span>
	    <br><br>
        
    <button type="submit" name="submit" value="Login">Login</button>
</form>
</div>
</div>
</div>
</body>
</html>




